<?php
/**
 * Plugin Name: SuperHero One Plugin
 * Plugin URI: http://www.wpbeaverbuilder.com
 * Description: A plugin to super heroe card
 * Version: 1.0
 * Author: Alfonso Hidalgo
 * Author URI: http://www.wpbeaverbuilder.com
 */
define( 'FL_MODULE_SUPERHEROEONE_DIR', plugin_dir_path( __FILE__ ) );
define( 'FL_MODULE_SUPERHEROEONE_URL', plugins_url( '/', __FILE__ ) );

require_once FL_MODULE_SUPERHEROEONE_DIR . 'classes/superheroe-one-loader.php'; 