<?php
/**
 * Plugin Name: SuperHero Plugin
 * Plugin URI: http://www.wpbeaverbuilder.com
 * Description: A plugin to super heroe card
 * Version: 2.0
 * Author: Alfonso Hidalgo
 * Author URI: http://www.wpbeaverbuilder.com
 */
define( 'FL_MODULE_SUPERHEROE_DIR', plugin_dir_path( __FILE__ ) );
define( 'FL_MODULE_SUPERHEROE_URL', plugins_url( '/', __FILE__ ) );

require_once FL_MODULE_SUPERHEROE_DIR . 'classes/superheroe-loader.php';